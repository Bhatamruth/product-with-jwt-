package com.casestudy.amruthvbhat.productcatalogueservice1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@EnableEurekaClient
@SpringBootTest
class ProductCatalogueService1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
