package com.casestudy.amruthvbhat.eurekaserverproductcatalogservice1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

@EnableEurekaServer
@SpringBootApplication
public class EurekaserverProductCatalogService1Application {

	public static void main(String[] args) {
		SpringApplication.run(EurekaserverProductCatalogService1Application.class, args);
	}

}
